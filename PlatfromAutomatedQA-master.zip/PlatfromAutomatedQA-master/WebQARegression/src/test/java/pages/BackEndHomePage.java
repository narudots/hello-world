package pages;

import org.openqa.selenium.WebDriver;

public class BackEndHomePage extends BackEndCommonPage{

	static String PageUrl = "";
	public static final String PageTitle = "Diversified Communications Web Platform" ;

	public BackEndHomePage(WebDriver CurrentTestDriver) {		

		super(CurrentTestDriver);		
		
	}	
}