/*package Backup;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coreapplicationclassesandinterfaces.Address;
import coreapplicationclassesandinterfaces.PaymentMethod;
import coreapplicationclassesandinterfaces.User;
import pages.FrontEndCheckoutConfirmationPage;
import pages.FrontEndShippingAddressPage;
import utils.ErrorHandlerUtils.TestException;
import utils.ExcelUtils.TestDataInput;
import utils.WebDriverControlUtils.WaitUtil;

public class ShippingAddressValidations extends BaseTest{		

		
	//************************************************************************************************
	// ** TEST 1 : CheckAddNewShippingAddresses **
	//************************************************************************************************
	
	@Test( dataProvider="AddressValidationTestData", groups ={"ShippingAddressValidations"})

	public static void AddNewShippingAddress(String[] ShippingAddressDetailsInArray){
		
		try {
			
			Address NewShippingAddressObj 	= new Address() ;
			NewShippingAddressObj.setAttributes(ShippingAddressDetailsInArray);

			// Navigate required pages to reach test screen
			
			User UserForTest = CommonTestLibrary.launchDefaultProductAndEnterUserDetails() ;	
			Address BillingAddressForTest = TestApplicationParams.getDefaultBillingAddress() ;			
			PaymentMethod PaymentMethodForTest 	= 	TestApplicationParams.getDefaultPaymentMethod() ;			
	
			CommonTestLibrary.enterBillingPaymentDetailsAndSubmit(	UserForTest,
																	BillingAddressForTest,
																	PaymentMethodForTest) ;
			
			Assert.assertEquals( CommonTestLibrary.enterShippingAddressDetailsAndSubmit(	
																			UserForTest, 
																			NewShippingAddressObj)
					, true ) ;
			
			FrontEndCheckoutConfirmationPage checkoutConfirmationPage = 
													new FrontEndCheckoutConfirmationPage(Driver) ;
			
			checkoutConfirmationPage.logout();
			
		} 
		catch ( TestException Te)
		{
			TestLog.logTestStep("Error/Exception : " + Te.getExceptionName());
			Te.printException();
			assert(false);
		}		
		catch (InterruptedException e){
			//do nothing		
		}
		catch ( Exception e)
		{
			e.printStackTrace();
			TestLog.logTestStep("Error/Exception " + e.getMessage());
			assert(false) ;
		}		
	}
	
	//************************************************************************************************
	// ** TEST 2 : AddressSaveOptionValidations **
	//************************************************************************************************
	
	@Test( dataProvider="AddressValidationTestData", groups ={"ShippingAddressValidations"})

	public static void AddressSaveOptions(String[] ShippingAddressDetailsInArray){
		
		try {
			
			Address NewShippingAddressObj 	= new Address() ;
			NewShippingAddressObj.setAttributes(ShippingAddressDetailsInArray);

			// Navigate required pages to reach test screen
			
			User UserForTest = CommonTestLibrary.launchDefaultProductAndEnterUserDetails() ;	
			Address BillingAddressForTest = TestApplicationParams.getDefaultBillingAddress() ;			
			PaymentMethod PaymentMethodForTest 	= 	TestApplicationParams.getDefaultPaymentMethod() ;			
	
			CommonTestLibrary.enterBillingPaymentDetailsAndSubmit(	UserForTest,
																	BillingAddressForTest,
																	PaymentMethodForTest) ;
			
			Assert.assertEquals( CommonTestLibrary.enterShippingAddressDetailsAndSubmit(	
																			UserForTest, 
																			NewShippingAddressObj)
					, true ) ;			
			
			FrontEndCheckoutConfirmationPage checkoutConfirmationPage = 
													new FrontEndCheckoutConfirmationPage(Driver) ;
					
			checkoutConfirmationPage.logout();			
			
		} 
		catch ( TestException Te)
		{
			TestLog.logTestStep("Error/Exception : " + Te.getExceptionName());
			Te.printException();
			assert(false);
		}		
		catch (InterruptedException e){
			//do nothing		
		}
		catch ( Exception e)
		{
			e.printStackTrace();
			TestLog.logTestStep("Error/Exception " + e.getMessage());
			assert(false) ;
		}		
	}
	
	//************************************************************************************************
	// ** TEST 3 : ShippingSameAsBilling Check **
	//************************************************************************************************
	
	@Test( groups ={"ShippingAddressValidations"})

	public static void ShippingSameAsBillingCheck(){
		
		try {
			
			// Navigate required pages to reach test screen
			
			User UserForTest = CommonTestLibrary.launchDefaultProductAndEnterUserDetails() ;	
			Address BillingAddressForTest = TestApplicationParams.getDefaultBillingAddress() ;			
			PaymentMethod PaymentMethodForTest 	= 	TestApplicationParams.getDefaultPaymentMethod() ;			
	
			CommonTestLibrary.enterBillingPaymentDetailsAndSubmit(	UserForTest,
																	BillingAddressForTest,
																	PaymentMethodForTest) ;
			
			Assert.assertEquals(CommonTestLibrary.chooseShippingSameAsBillingOption(), true ) ;
			
			FrontEndCheckoutConfirmationPage checkoutConfirmationPage = 
					new FrontEndCheckoutConfirmationPage(Driver) ;

			checkoutConfirmationPage.logout();			
		} 
		catch ( TestException Te)
		{
			TestLog.logTestStep("Error/Exception : " + Te.getExceptionName());
			Te.printException();
			assert(false);
		}		
		catch (InterruptedException e){
			//do nothing		
		}
		catch ( Exception e)
		{
			e.printStackTrace();
			TestLog.logTestStep("Error/Exception " + e.getMessage());
			assert(false) ;
		}		
	}
	
	//************************************************************************************************
	// ** TEST 4 : Multiple Shipping Addresses **
	//************************************************************************************************
	
	@Test( dataProvider="AddressValidationTestData", groups ={"ShippingAddressValidations"})

	public static void MultipleShippingAddresses(String[] ShippingAddressDetailsInArray){
		
		try {
			
			Address NewShippingAddressObj 	= new Address() ;
			NewShippingAddressObj.setAttributes(ShippingAddressDetailsInArray);

			// Navigate required pages to reach test screen
			
			User UserForTest = CommonTestLibrary.launchDefaultProductAndEnterUserDetails() ;	
			Address BillingAddressForTest = TestApplicationParams.getDefaultBillingAddress() ;			
			PaymentMethod PaymentMethodForTest 	= 	TestApplicationParams.getDefaultPaymentMethod() ;			
			
			CommonTestLibrary.enterBillingPaymentDetailsAndSubmit(	UserForTest,
																	BillingAddressForTest,
																	PaymentMethodForTest) ;
			
			FrontEndShippingAddressPage AddNewShippingAddressPage = 
					new FrontEndShippingAddressPage(	Driver,
														UserForTest,
														NewShippingAddressObj) ;
			// Create First Address
																			
			if (AddNewShippingAddressPage.createNewShippingAddress()){					
								
				WaitUtil.waitFor(Driver, "THREAD_SLEEP", (long)1000);
				AddNewShippingAddressPage.clickAddNewShippingAddress() ;
				
				Address AdditionalShippingAddress = TestApplicationParams.getDefaultShippingAddress() ;
				
				FrontEndShippingAddressPage AdditionalShippingAddressPage = 
						new FrontEndShippingAddressPage(	Driver,
															UserForTest,
															AdditionalShippingAddress) ;
				
				Assert.assertEquals(AddNewShippingAddressPage.createNewShippingAddress(), true) ;
				
				TestLog.logTestStep("Logout from the account");
											
				AdditionalShippingAddressPage.logout() ;								
				WaitUtil.waitFor(Driver,"THREAD_SLEEP", (long)1000);
				
			}
			
		} 
		catch ( TestException Te)
		{
			TestLog.logTestStep("Error/Exception : " + Te.getExceptionName());
			Te.printException();
			assert(false);
		}		
		catch (InterruptedException e){
			//do nothing		
		}
		catch ( Exception e)
		{
			e.printStackTrace();
			TestLog.logTestStep("Error/Exception " + e.getMessage());
			assert(false) ;
		}		
	}
	
	//************************************************************************************************					
	// ** DATA PROVIDER 1 : DomesticAndInternationAddresses	**
	//************************************************************************************************
			
	@DataProvider ( name = "AddressValidationTestData" )
	
	public static String[][] fetchShippingAddresses(){
		
		String[][] ShippingAddressTestData ;
		
		ShippingAddressTestData = TestDataInput.getMatchedInputTableRowsForApplCodeAndTestDataType(
													Address.TestDataSheetName,
													TestApplicationParams.getCurrentTestApplication(),
													"AddressValidationTestData");				
		return (ShippingAddressTestData);
		
	}	
		
}*/