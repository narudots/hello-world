/*package Backup;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coreapplicationclassesandinterfaces.Address;
import coreapplicationclassesandinterfaces.PaymentMethod;
import coreapplicationclassesandinterfaces.Product;
import coreapplicationclassesandinterfaces.User;
import pages.FrontEndCheckoutConfirmationPage;
import pages.FrontEndCommonPage;
import pages.FrontEndHomePage;
import pages.FrontEndMyAccountPage;
import pages.FrontEndNewUserProfilePage;
import pages.FrontEndOrderSuccessPage;
import utils.ErrorHandlerUtils.TestException;
import utils.ExcelUtils.TestDataInput;
import utils.WebDriverControlUtils.NavigationUtil;

public class ProductPurchaseValidations extends BaseTest{		


	//************************************************************************************************
	// ** TEST 1 : AddIOFMMembershipProducts **
	//************************************************************************************************
	
	@Test( dataProvider="IOFMMembershipValidationTestData", groups ={"IOFMMembershipValidations"})

	public static void IOFMMembershipProductPurchase(String[] ProductDetailsInArray){
		
		try {			
				CommonTestLibrary.purchaseIOFMMembershipProduct(ProductDetailsInArray) ;
				new FrontEndCommonPage(Driver).logout() ;
		} 
		catch ( TestException Te)
		{
			TestLog.logTestStep("Error/Exception : " + Te.getExceptionName());
			Te.printException();
			assert(false);
		}		
		catch (InterruptedException e){
			//do nothing		
		}
		catch ( Exception e)
		{
			e.printStackTrace();
			TestLog.logTestStep("Error/Exception " + e.getMessage());
			assert(false) ;
		}		
	}
	
	@Test( dataProvider="ProductPurchaseTestData", groups ={"ProductPurchaseValidations"})

	public static void PurchaseProducts(String[] ProductDetailsInArray){
		
		try {
			
			// Step 1 - Get the  product to be tested
			
			Product ProductForTest 	= new Product() ;
			ProductForTest.setAttributes(ProductDetailsInArray);
			
			TestLog.logTestStep("Product checkout");
			
			// Step 2 - Navigate to the  product page to be tested
			
			NavigationUtil.navigate( Driver,
														ProductForTest.getProductCheckoutLink(),
														FrontEndHomePage.getPageUrl()+FrontEndNewUserProfilePage.PageUrl) ;
			
			User UserForTest = CommonTestLibrary.enterUserDetails() ;	
			Address BillingAddressForTest = TestApplicationParams.getDefaultBillingAddress() ;			
			PaymentMethod PaymentMethodForTest 	= 	TestApplicationParams.getDefaultPaymentMethod() ;
			
			CommonTestLibrary.enterBillingPaymentDetailsAndSubmit(	UserForTest,
																														BillingAddressForTest,
																														PaymentMethodForTest) ;	
			
			CommonTestLibrary.chooseShippingSameAsBillingOption() ;	

			// Step 9  -  Confirm order 
			
			FrontEndCheckoutConfirmationPage  confirmOrderPage = new FrontEndCheckoutConfirmationPage(Driver) ;
			
			Assert.assertEquals(confirmOrderPage.confirmOrder(),true) ;
			
			// Step 10 - Launch My Account page and view orders
			
			FrontEndOrderSuccessPage	OrderSuccessPage = new FrontEndOrderSuccessPage(Driver) ;
			
			OrderSuccessPage.launchMyAccountPage() ;
			
			FrontEndMyAccountPage		MyAccountPage = new FrontEndMyAccountPage(Driver) ;
			
			MyAccountPage.viewOrders() ;
			
			MyAccountPage.logout();
			
			
		} 
		catch ( TestException Te)
		{
			TestLog.logTestStep("Error/Exception : " + Te.getExceptionName());
			Te.printException();
			assert(false);
		}		
		catch (InterruptedException e){
			//do nothing		
		}
		catch ( Exception e)
		{
			e.printStackTrace();
			TestLog.logTestStep("Error/Exception " + e.getMessage());
			assert(false) ;
		}		
	}
				
	//************************************************************************************************					
	// ** DATA PROVIDER 1 : IOFM Membership Data	**
	//************************************************************************************************
			
	@DataProvider ( name = "IOFMMembershipValidationTestData" )
	
	public static String[][] fetchMembershipData(){
		
		String[][] IOFMMembershipData ;
		
		IOFMMembershipData = TestDataInput.getMatchedInputTableRowsForApplCodeAndTestDataType(
																		Product.TestDataSheetName,
																		TestApplicationParams.getCurrentTestApplication(),
																		"MembershipValidationTestData");				
		return (IOFMMembershipData);
		
	}	
	
	//************************************************************************************************					
	// ** DATA PROVIDER 1 : Product Data	**
	//************************************************************************************************
			
	@DataProvider ( name = "ProductPurchaseTestData" )
	
	public static String[][] fetchProductData(){
		
		String[][] ProductPurchaseTestData ;
		
		ProductPurchaseTestData = TestDataInput.getMatchedInputTableRowsForApplCodeAndTestDataType(
																		Product.TestDataSheetName,
																		TestApplicationParams.getCurrentTestApplication(),
																		"ProductPurchaseTestData");				
		return (ProductPurchaseTestData);
		
	}	
		
}*/